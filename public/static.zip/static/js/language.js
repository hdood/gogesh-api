const  lan = {
  ar: {
    title: "؟هل انت متأكد",
    yes: "نعم",
    no: "لا",
  },
  en: {
    title: "are yoy sure ?",
    yes: "yes",
    no: "no",
  },
};

module.exports = lan;
